"""
Lakewood Township (NJ) daily permit status checker - contractor edition.

Searches the township's public FastTrackGov portal for all OPEN permits
filed under the contractor name below, in BOTH databases:
  - Construction permits  (Construction Inquiry)
  - Zoning permits        (Zoning Inquiry)

Every morning it emails a summary organized as:
  1. CHANGED since yesterday (status changed)
  2. APPROVED / CLOSED OUT (was open yesterday, no longer in the open list)
  3. NEW (appeared for the first time)
  4. STILL OPEN (the current pipeline)

Because it only pulls OPEN permits, historical already-approved permits
never appear. The first run establishes the baseline of what's open now.

Required environment variables (GitHub Actions secrets):
  GMAIL_ADDRESS       - Gmail address that SENDS the email
  GMAIL_APP_PASSWORD  - Gmail "app password" for that account
  EMAIL_TO            - recipient (set in the workflow file)
"""

import json
import os
import smtplib
import sys
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path
from zoneinfo import ZoneInfo

from playwright.sync_api import sync_playwright

CONTRACTOR_NAME = "Baron Builders LLC"

PORTALS = [
    ("Construction", "https://lakewoodnj.portal.fasttrackgov.com/Permits/Search.aspx?microapp=c"),
    ("Zoning", "https://lakewoodnj.portal.fasttrackgov.com/Permits/Search.aspx?microapp=njlanduse"),
]

STATE_FILE = Path("state.json")
MAX_PAGES = 20  # safety cap on result pagination


def parse_results(page, portal_name):
    """Read every data row from result tables whose header mentions status/permit."""
    records = {}
    for table in page.locator("table").all():
        rows = table.locator("tr").all()
        if len(rows) < 2:
            continue
        headers = [c.inner_text().strip() for c in rows[0].locator("th, td").all()]
        header_line = " ".join(headers).lower()
        if "status" not in header_line and "permit" not in header_line \
                and "application" not in header_line:
            continue
        for row in rows[1:]:
            cells = [c.inner_text().strip() for c in row.locator("td").all()]
            if not cells or len(cells) < 2:
                continue
            fields = {h: v for h, v in zip(headers, cells) if h}
            # Pick an identifier: first field whose header looks like an ID/number
            ident = ""
            for h, v in fields.items():
                hl = h.lower()
                if any(k in hl for k in ("application", "permit", "id", "number")) and v:
                    ident = v
                    break
            if not ident:
                ident = " | ".join(cells[:2])
            status = ""
            for h, v in fields.items():
                if "status" in h.lower():
                    status = v
                    break
            addr = ""
            for h, v in fields.items():
                if any(k in h.lower() for k in ("address", "location", "street")):
                    addr = v
                    break
            key = f"{portal_name}:{ident}"
            records[key] = {
                "portal": portal_name,
                "id": ident,
                "status": status or "(open - no status column)",
                "address": addr,
                "fields": fields,
            }
    return records


def search_portal(page, portal_name, url):
    """Run one contractor search on one portal, following pagination."""
    page.goto(url, wait_until="networkidle", timeout=60000)

    # Limit to OPEN permits so old approved/closed permits never appear.
    try:
        for sel in page.locator("select").all():
            options = [o.inner_text().strip() for o in sel.locator("option").all()]
            if "Open" in options and "Closed" in options:
                sel.select_option(label="Open")
                break
    except Exception:
        pass  # if the control changed, default search still works

    # Fill the Contractor/Agent box.
    box = page.locator(
        "xpath=//*[contains(normalize-space(text()),'Contractor/Agent')]"
        "/following::input[@type='text'][1]"
    )
    box.fill(CONTRACTOR_NAME)

    page.locator(
        "xpath=//input[@value='Search'] | //button[normalize-space()='Search'] | "
        "//a[normalize-space()='Search']"
    ).first.click()
    page.wait_for_load_state("networkidle", timeout=60000)

    records = parse_results(page, portal_name)

    # Follow "Next" pagination links if the grid has them.
    for _ in range(MAX_PAGES):
        nxt = page.locator(
            "xpath=//a[normalize-space()='Next' or normalize-space()='>' "
            "or contains(@title,'Next')]"
        )
        if nxt.count() == 0:
            break
        try:
            nxt.first.click()
            page.wait_for_load_state("networkidle", timeout=60000)
            more = parse_results(page, portal_name)
            if not more or all(k in records for k in more):
                break
            records.update(more)
        except Exception:
            break
    return records


def esc(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def row_html(rec, note="", note_color="#c0392b"):
    note_html = f"<br><b style='color:{note_color}'>{esc(note)}</b>" if note else ""
    return (
        f"<tr>"
        f"<td style='padding:8px;border:1px solid #ddd'><b>{esc(rec['id'])}</b>"
        f"<br><span style='color:#666;font-size:12px'>{esc(rec['portal'])}"
        f"{' &middot; ' + esc(rec['address']) if rec['address'] else ''}</span></td>"
        f"<td style='padding:8px;border:1px solid #ddd'>{esc(rec['status'])}{note_html}</td>"
        f"</tr>"
    )


def section(title, rows, color="#333"):
    if not rows:
        return ""
    return (
        f"<h3 style='color:{color};margin-bottom:6px'>{title}</h3>"
        f"<table style='border-collapse:collapse;width:100%;margin-bottom:18px'>"
        f"<tr style='background:#f4f4f4'>"
        f"<th style='padding:8px;border:1px solid #ddd;text-align:left'>Permit / Application</th>"
        f"<th style='padding:8px;border:1px solid #ddd;text-align:left'>Status</th></tr>"
        f"{''.join(rows)}</table>"
    )


def build_email(current, previous, first_run, now_str):
    changed, closed_out, new, still_open = [], [], [], []

    for key, rec in current.items():
        prev = previous.get(key)
        if prev is None:
            if first_run:
                still_open.append(row_html(rec))
            else:
                new.append(row_html(rec, "NEW", "#1a5fb4"))
        elif prev.get("status") != rec["status"]:
            changed.append(row_html(rec, f"CHANGED (was: {prev.get('status')})"))
        else:
            still_open.append(row_html(rec))

    for key, prev in previous.items():
        if key not in current:
            closed_out.append(row_html(prev, "No longer open - likely approved/issued "
                                              "(or withdrawn). Verify on the portal.",
                                        "#1a7f37"))

    n_updates = len(changed) + len(closed_out) + len(new)
    if first_run:
        subject = f"Lakewood permits - baseline: {len(current)} open - {now_str}"
        intro = ("First run - this is the baseline of everything currently open under "
                 f"<b>{esc(CONTRACTOR_NAME)}</b>. From tomorrow, changes appear at the top.")
    elif n_updates:
        subject = f"[{n_updates} update{'s' if n_updates != 1 else ''}] Lakewood permits - {now_str}"
        intro = ""
    else:
        subject = f"Lakewood permits - no changes - {now_str}"
        intro = "No changes since yesterday."

    body = (
        f"<div style='font-family:Arial,sans-serif;max-width:680px'>"
        f"<h2 style='margin-bottom:4px'>Lakewood Township permit status</h2>"
        f"<p style='color:#666;margin-top:0'>{now_str} &middot; contractor: "
        f"{esc(CONTRACTOR_NAME)} &middot; {len(current)} open permit(s)</p>"
        f"{('<p>' + intro + '</p>') if intro else ''}"
        f"{section('Status changed since yesterday', changed, '#c0392b')}"
        f"{section('Approved / closed out since yesterday', closed_out, '#1a7f37')}"
        f"{section('New applications', new, '#1a5fb4')}"
        f"{section('Still open (current pipeline)', still_open)}"
        f"<p style='color:#999;font-size:12px'>Source: lakewoodnj.portal.fasttrackgov.com "
        f"(Construction + Zoning Inquiry, open permits only). Automated message.</p></div>"
    )
    return subject, body


def send_email(subject, html):
    sender = os.environ["GMAIL_ADDRESS"]
    password = os.environ["GMAIL_APP_PASSWORD"]
    recipient = os.environ.get("EMAIL_TO", sender)

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = recipient
    msg.attach(MIMEText(html, "html"))

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(sender, password)
        server.sendmail(sender, [recipient], msg.as_string())


def main():
    first_run = not STATE_FILE.exists()
    previous = {} if first_run else json.loads(STATE_FILE.read_text())

    current = {}
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        for portal_name, url in PORTALS:
            try:
                current.update(search_portal(page, portal_name, url))
            except Exception as e:
                errors.append(f"{portal_name} search failed: {e}")
        browser.close()

    if errors and not current:
        # Total failure - don't wipe state; send an alert instead.
        now_str = datetime.now(ZoneInfo("America/New_York")).strftime("%A, %B %d, %Y")
        send_email(
            f"Lakewood permit checker ERROR - {now_str}",
            "<p>The permit checker could not read the portal today:</p><pre>"
            + esc("\n".join(errors)) + "</pre><p>Yesterday's data was kept.</p>",
        )
        sys.exit(1)

    now_str = datetime.now(ZoneInfo("America/New_York")).strftime("%A, %B %d, %Y %I:%M %p")
    subject, html = build_email(current, previous, first_run, now_str)
    if errors:
        html += ("<p style='color:#c0392b;font-size:12px'>Warning - part of the search "
                 "failed today: " + esc("; ".join(errors)) + "</p>")
    send_email(subject, html)

    STATE_FILE.write_text(json.dumps(
        {k: {"portal": v["portal"], "id": v["id"], "status": v["status"],
             "address": v["address"]} for k, v in current.items()},
        indent=2,
    ))
    print(f"Sent: {subject} ({len(current)} open permits)")


if __name__ == "__main__":
    main()
