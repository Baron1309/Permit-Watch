# Lakewood Permit Watch — Baron Builders LLC

Every morning this emails **Joseph@baronbuilders.com** the status of every
OPEN permit filed under **Baron Builders LLC** with Lakewood Township, NJ —
pulled from BOTH the Construction Inquiry and Zoning Inquiry databases on
the township's public portal. No township login is needed.

The email is organized so the important stuff is on top:

1. **Status changed since yesterday** — e.g. moved from plan review to issued
2. **Approved / closed out since yesterday** — was open yesterday, gone from
   the open list today (this is your approval notification, shown once)
3. **New applications** — anything newly filed under your name, including
   zoning applications, automatically — no list to maintain
4. **Still open** — your current pipeline

Because it only pulls OPEN permits, old already-approved permits never
appear. The very first email is a one-time baseline of what's open now.

It runs free on GitHub Actions — no computer needs to stay on.

## One-time setup (~15 minutes)

### 1. Create a Gmail app password (for sending)
1. At https://myaccount.google.com/security turn ON **2-Step Verification**
   (app passwords require it).
2. Go to https://myaccount.google.com/apppasswords and create one named
   "permit watch". Copy the 16-character password.

Tip: a free throwaway Gmail just for sending works fine.

### 2. Create a GitHub repository
1. Sign up / log in at https://github.com
2. Create a new **private** repository (e.g. `permit-watch`).
3. Upload everything in this folder, keeping the folder structure —
   especially `.github/workflows/daily-permit-email.yml`.
   (On the website: "Add file" → "Upload files"; drag the folder in.)

### 3. Add two secrets
Repo → **Settings → Secrets and variables → Actions → New repository secret**:

| Name                 | Value                                     |
|----------------------|-------------------------------------------|
| `GMAIL_ADDRESS`      | the Gmail address that sends the email    |
| `GMAIL_APP_PASSWORD` | the 16-character app password from step 1 |

The recipient (Joseph@baronbuilders.com) and the contractor name
(Baron Builders LLC) are already written into the files — to change them
later, edit `.github/workflows/daily-permit-email.yml` (recipient) or the
`CONTRACTOR_NAME` line at the top of `check_permits.py`.

### 4. TEST RUN
Go to the **Actions** tab → "Daily Lakewood permit email" → **Run
workflow** button. Within a few minutes the baseline email should arrive
at Joseph@baronbuilders.com listing every currently-open permit.
After that it runs automatically every morning (7 AM NJ time in summer,
6 AM in winter — see the note in the workflow file to adjust).

## If something looks wrong
- **Baseline email is empty or missing permits:** the contractor name may
  not exactly match the township's records. Search manually at
  https://lakewoodnj.portal.fasttrackgov.com/Permits/Search.aspx?microapp=c
  (Contractor/Agent box) to find the exact spelling, then update
  `CONTRACTOR_NAME` in `check_permits.py`.
- **No email at all:** Actions tab → click the latest run → read the log.
  Usually a typo'd secret name or app password.
- **Portal errors:** if the township's site is down or changes, the system
  emails you an error notice instead of a summary and keeps yesterday's
  data so nothing is falsely reported as approved.
